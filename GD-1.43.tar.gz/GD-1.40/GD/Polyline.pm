
#
# new perl module
# GD::Polyline
#
# work in progress!
# 7/11/2002
# Dan Harasty
# harasty@cpan.org
#
# see POD at end of file
#

use strict;

package GD::Polyline;

use GD;
use Carp 'croak','carp';

use base 'GD::Polygon';

# base class implements:
# 	new
#	addPt
#	getPt
#	setPt
#	deletePt
#	toPt
#	length
#	vertices
#	bounds
#	offset
#	map
#	scale
#	transform

our $bezSegs = 20;
our $autoClose = undef;

sub new {
	my $class = shift;
	my $self = $class->SUPER::new(@_);
	my $opts = {@_};
	$self->{autoClose} = exists $opts->{autoClose} ? $opts->{autoClose} : $autoClose;
	return $self;
}

#
# autoClose
# 
# get/set the autoClose attribute of the polyline
# 

sub autoClose {
    my $self = shift;

	$self->{autoClose} = $_[0] if @_;
	
	return $self->{autoClose};
}

#sub segLength {
#    my $self = shift;
#    my @points = $self->vertices();
#	
#}

sub toSpline {
    my $self = shift;
    my @points = $self->vertices();

	unless (@points > 1 and @points % 3 == 1) {
	    carp "Attempt to call toSpline() with invalid set of control points";
		return undef;
	}
    
    my ($ap1, $dp1, $dp2, $ap2); # ap = anchor point, dp = director point
    $ap1 = shift @points;
    
    my $bez = new GD::Polyline;
    $bez->addPt(@$ap1);
    
    while (@points) {
    	($dp1, $dp2, $ap2) = splice(@points, 0, 3);
    	
		for (1..$bezSegs) {
			my ($t0, $t1, $c1, $c2, $c3, $c4, $x, $y); 
			
			$t1 = $_/$bezSegs;
			$t0 = (1 - $t1);
			
			# possible optimization:
			# these coefficient could be calculated just once and cached in an array
			$c1 =     $t0 * $t0 * $t0;
			$c2 = 3 * $t0 * $t0 * $t1;
			$c3 = 3 * $t0 * $t1 * $t1;
			$c4 =     $t1 * $t1 * $t1;
	
			$x = $c1 * $ap1->[0] + $c2 * $dp1->[0] + $c3 * $dp2->[0] + $c4 * $ap2->[0];
			$y = $c1 * $ap1->[1] + $c2 * $dp1->[1] + $c3 * $dp2->[1] + $c4 * $ap2->[1];
		
			$bez->addPt($x, $y);
		}
    	
    	$ap1 = $ap2;
    }
    
	return $bez;
}

sub addControlPoints {
    my $self = shift;
    my @points = $self->vertices();

	unless (@points > 1) {
	    carp "Attempt to call addControlPoints() with too few vertices in polyline";
		return undef;
	}
    
    my ($ap1, $dp1, $dp2, $ap2); # ap = anchor point, dp = director point
    $ap1 = shift @points;
    
    my $ctrl = new GD::Polyline;
    $ctrl->addPt(@$ap1);
    
    while (@points) {

    	$ap2 = shift(@points);    	

		# this is a very simplistic (and not very appealing algorithm)
		# and it is JUST a place holder ... I've got the good stuff
		# implemented elsewhere... DJH
    	$dp1 = [$ap1->[0] + 25, $ap1->[1]];
    	$dp2 = [$ap2->[0] - 25, $ap2->[1]];

		$ctrl->addPt(@$dp1);
		$ctrl->addPt(@$dp2);
		$ctrl->addPt(@$ap2);
    	
    	$ap1 = $ap2;
    }
    
	return $ctrl;
}

sub GD::Image::polyline {
    my $self = shift;	# the GD::Image
    my $p    = shift;	# the GD::Polyline (or GD::Polygon)
    my $c    = shift;	# the color
    my @points = $p->vertices();
    my $p1 = shift @points;
    my $p2;
    while ($p2 = shift @points) {
	    $self->line(@$p1, @$p2, $c);
    	$p1 = $p2;
    }
}	    


1;
__END__

=pod

=head1 NAME

GD::Polyline - Bezier curves and other open forms for GD library

=head1 SYNOPSIS

=head1 POLYLINE METHODS

Polylines are a lot like polygons, except when rendered 
they don't automatically "close" by drawing a segment from 
the last point to the first point.  In fact GD::Polyline is
a subclass of GD::Polygon, so all polygon methods may be used.

The polyline  
introduces several methods, such as one to create
curves by using Bezier spline algorithms (and other good
stuff in the future).

This object is a newer feature of GD and should be
considered subject to change in future releases, and/or
possibly folded in to the existing polygon object.

=over 5

=item C<new>

C<GD::Polyline-E<gt>new> I<class method>

Create an empty polyline with no vertices.

	$polyline = new GD::Polyline;

	$polyline->addPt(  0,  0);
	$polyline->addPt(  0,100);
	$polyline->addPt( 50,100);
	$polyline->addPt(100,  0);

	$image->polyline($polyline,$color) # a new object method on GD::Image

=item C<autoClose>

C<$polyline-E<gt>autoClose(newVal)> I<object method>

Get/set the autoClose attribute of the polyline, which defaults
to false.

	$polyline->autoClose(1);
	$autoClose = $polyline->autoClose();

It can also be set at object creation time:

	$polyline = new GD::Polyline 'autoClose' => 1;

For the most part, polylines with autoClose true behave
as if the first point is duplicated as the last point.

To change the default for new polylines, set the value of 
$GD::Polyline::autoClose.

=item C<toSpline>

C<$polyline-E<gt>toSpline()> I<object method>

Create a new polyline which is a reasonably smooth curve
using cubic spline algorithms, often referred to as Bezier
curves.  The "source" polyline is called the "control polyline".
If autoClose is false, the control polyline must 
have 4, 7, 10, or some number of vertices of equal to 3n+1.
If autoClose is true, the control polyline must 
have 3, 6, 9, or some number of vertices of equal to 3n.

	$spline = $polyline->toSpline();	
	$image->polyline($spline,$red);

In brief, groups of four points from the control polyline
are considered "control
points" for a given portion of the spline: the first and
fourth are "anchor points", and the spline passes through
them; the second and third are "director points".  The
spline does not pass through director points, however the
spline is tangent to the line segment from anchor point to
adjacent director point.

The next portion of the spline reuses the previous portion's
last anchor point.  The spline will have a cusp
(non-continuous slope) at an anchor point, unless the anchor
points and its adjacent director point are colinear.

In the current implementation, toSpline() return a fixed
number of segments in the returned polyline per set-of-four
control points.  In the future, this and other parameters of
the algorithm may be configurable.

For more info on Bezier splines, see [ref needed].

=item C<addControlPoints>

C<$polyline-E<gt>addControlPoints()> I<object method>

So you say: "OK.  Splines sound cool.  But how can I
get my anchor points and its adjacent director point to be
colinear so that I have a nice smooth curves from my
polyline?"  Relax!  For The Lazy: addControlPoints() to the
rescue.

addControlPoints() returns a polyline that can serve
as the control polyline for toSpline(), which returns
another polyline which is the spline.  Is your head spinning
yet?  Think of it this way:

=over 5

=item +

If you have a polyline, and you have already put your
control points where you want them, call toSpline() directly.
Remember, only every third vertex will be "on" the spline.

You get something that looks like the spline "inscribed" 
inside the control polyline.

=item +

If you have a polyline, and you want all of its vertices on
the resulting spline, call addControlPoints() and then
toSpline():

	$control = $polyline->addControlPoints();	
	$spline  = $control->toSpline();	
	$image->polyline($spline,$red);

You get something that looks like the control polyline "inscribed" 
inside the spline.

=back

Adding "good" control points is subjective; this particular 
algorithm reveals its author's tastes.  
In the future, you may be able to alter the taste slightly
via parameters to the algorithm.  For The Hubristic: please 
build a better one!

And for The Impatient: note that addControlPoints() returns a
polyline, so you can pile up the the call like this, 
if you'd like:

	$image->polyline($polyline->addControlPoints()->toSpline(),$mauve);

=item C<An Example>

One more example (for good luck):

	$cloverControl = new GD::Polyline;
	$cloverControl->addPt(45,45);
	$cloverControl->addPt(10,10);
	$cloverControl->addPt(90,10);
	$cloverControl->addPt(55,45);
	$cloverControl->addPt(90,10);
	$cloverControl->addPt(90,90);
	$cloverControl->addPt(55,55);
	$cloverControl->addPt(90,90);
	$cloverControl->addPt(10,90);
	$cloverControl->addPt(45,55);
	$cloverControl->addPt(10,90);
	$cloverControl->addPt(10,10);
	$cloverControl->addPt(45,45);
	$clover = $cloverControl->toSpline();	
	$clover->offset(50,0);
	$image->filledPolygon($clover,$green);
	
Don't forget: a polyline is a polygon, so GD::Polygon methods 
like offset() can be used, and they can be used in
GD::Image methods like filledPolygon().

=back

=head1 AUTHOR

Dan Harasty E<lt>DHarasty@skyoptix.comE<gt>

This module is copyright 2002, Dan Harasty.  It can be
distributed under the same terms as Perl itself.

=head1 SEE ALSO

L<GD>

=cut

