#!/usr/bin/perl
#
# sample code for GD::Polyline
#
# work in progress!
# 7/11/2002
# Dan Harasty
# harasty@cpan.org
#

use GD;
use GD::Polyline;

$image = new GD::Image (400,300);
 
$white = $image->colorAllocate(255,255,255);
$black = $image->colorAllocate(0,0,0);
$red = $image->colorAllocate(255,0,0);   
$green = $image->colorAllocate(0,255,0);   
$blue = $image->colorAllocate(0,0,255);

$brush_width = 3;
$brush = new GD::Image($brush_width,$brush_width);
$brush->transparent($brush->colorAllocate(255,255,255));
$brush->filledRectangle(0,0,$brush_width,$brush_width,$brush->colorAllocate(255,128,0));
$image->setBrush($brush);

if (1) {
	$polyline = new GD::Polyline;

	# simple polyline
	
	$polyline->addPt(  0,  0);
	$polyline->addPt(  0,100);
	$polyline->addPt( 50,125);
	$polyline->addPt(100,  0);

	$image->polyline($polyline,$black);	# base polyline in black
 				# this will be the control polygon, too

	# sample call of toSpline, using above polyline
	# as the control polyline
	
	$spline = $polyline->toSpline();	# spline polyline in red
	$image->polyline($spline,$red);

	# sample call of addControlPoints
	
	$polyline->offset(50,150);
	$image->polyline($polyline,$black);	# base polyline in black
	$control = $polyline->addControlPoints();	
	$image->polyline($control,$blue);	# control polyline in blue
	$spline  = $control->toSpline();
	$image->polyline($spline,$red);		# spline polyline in red

	# picturesque example of a spline
	# ... filled as a regular GD::Polygon

	$cloverControl = new GD::Polyline;
	$cloverControl->addPt(45,45);
	$cloverControl->addPt(10,10);
	$cloverControl->addPt(90,10);
	$cloverControl->addPt(55,45);
	$cloverControl->addPt(90,10);
	$cloverControl->addPt(90,90);
	$cloverControl->addPt(55,55);
	$cloverControl->addPt(90,90);
	$cloverControl->addPt(10,90);
	$cloverControl->addPt(45,55);
	$cloverControl->addPt(10,90);
	$cloverControl->addPt(10,10);
	$cloverControl->addPt(45,45);
	$clover = $cloverControl->toSpline();	
	$clover->offset(200,0);	# offset would have worked on $cloverControl, too
	$image->filledPolygon($clover,$green);
	
}

if (0) {
	$p1 = new GD::Polyline;
	
	$p1->addPt( 10,10);
	$p1->addPt( 90,-50);
	$p1->addPt( 50,50);
	$p1->addPt(100,10);
	
	$p1->addPt(150,-30);
	$p1->addPt(180,90);
	$p1->addPt(280,10);
	
	print "p1 is a ". ref($p1) . "\n";
	
	$image->polygon($p1, $black);
	
	$p1->offset(30, 90);
	
	$GD::Polyline::bezSegs = 10;
	
	$p2 = $p1->toSpline();
	
	$image->polyline($p2, gdBrushed);
	$image->polyline($p1, $blue);

	# check to see that other polygon transformation 
	# methods still work on polylines..
		
	$p2->offset(-30, 100);
	$p2->scale(2, 1);
	$image->polyline($p2, $green);
	
	$p2->transform(0, 0.5, 1, 0, 70, 0);
	$image->polyline($p2, $red);

	print "length of p1 is " . $p1->length() . "\n";
	print "length of p2 is " . $p2->length() . "\n";
}

binmode STDOUT;
print $image->png;

__END__

WriteToBinaryFile("polyline.png", $image->png);

print "ok! " . localtime() . "\n";

#======================
#helper functions

sub WriteToBinaryFile {
	my $file = shift || return 0;
	my $contents = shift || "";

	open (NEWFILE, ">" . $file) or die "couldn't write to file $file";
	binmode NEWFILE;
	print NEWFILE $contents;
	close(NEWFILE);

}

